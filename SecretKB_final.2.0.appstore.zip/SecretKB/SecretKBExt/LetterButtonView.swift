//
//  LetterButtonView.swift
//  Wordle
//
//  Created by Stewart Lynch on 2022-01-20.
//

import SwiftUI

struct LetterButtonView: View {
    @EnvironmentObject var vc: KeyboardViewController
    @Environment(\.colorScheme) var colorScheme
    var width: CGFloat
    
    var letter: String
    @State private var isPressed = false

    var body: some View {
//        Button {
//            DispatchQueue.main.async {
//                vc.addToCurrentWordK(letter)
//            }
//            //textDocumentProxy.insertText("\(letter)")
//            //addToCurrentWord(letter)
//
//        } label: {
//            Text(letter)
//                .font(.system(size: 20))
//                //.background(.gray)
//                .foregroundStyle(colorScheme == .dark ? .white : .black)
//                .background((colorScheme == .dark ? Color(red: 106.0/255.0, green: 106.0/255.0, blue: 106.0/255.0) : .white))
////                .cornerRadius(6)
//                //.contentShape(Rectangle())
//                .frame(width: width, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
//
//                .padding()
//
//        }
//        .background(Color.clear)
        //.contentShape(Rectangle())
        
        
//        ZStack {
//            Capsule()
//                .foregroundColor(.clear)
            
//            Rectangle().frame(width: width, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight).opacity(0.001)
//                                .layoutPriority(-1)
//                                .cornerRadius(6)
//                                .background((colorScheme == .dark ? Color(red: 106.0/255.0, green: 106.0/255.0, blue: 106.0/255.0) : .white))
            
            Text(letter)
                .font(.system(size: 24))
                //.background(.gray)
                .foregroundColor(colorScheme == .dark ? .white : .black)
                .frame(width: width-4, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
                .background((colorScheme == .dark ? Color(red: 106.0/255.0, green: 106.0/255.0, blue: 106.0/255.0) : .white))
                .cornerRadius(6)

//                .tappablePadding(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4), onTap: {
//                    DispatchQueue.main.async {
//                        vc.addToCurrentWordK(letter)
//                    }
//                })
//        }
        .tappablePadding(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4), onTap: {
            DispatchQueue.main.async {
                vc.addToCurrentWordK(letter)
            }
        })
        //.contentShape(Rectangle())
        //.shadow(color: .black, radius: 4, x: 0, y: 4)

        
        .scaleEffect(isPressed ? 1.2 : 1.0, anchor: .bottom)
    .opacity(isPressed ? 0.6 : 1.0)
//    .onTapGesture {
//        DispatchQueue.main.async {
//            vc.addToCurrentWordK(letter)
//        }
//    }
    .pressEvents {
        // On press
        withAnimation(.easeInOut(duration: 0.1)) {
            isPressed = true
        }
    } onRelease: {
        withAnimation {
            isPressed = false
        }
    }
    
        //.buttonStyle(.plain)
        //.background((colorScheme == .dark ? Color(red: 106.0/255.0, green: 106.0/255.0, blue: 106.0/255.0) : .white))
        //.cornerRadius(6)
        .shadow(color: colorScheme == .dark ? .black : .gray, radius: 0, x: 0, y: 1)

    }
}

struct LetterButtonView_Previews: PreviewProvider {
    static var previews: some View {
        LetterButtonView(width: (UIScreen.main.bounds.width/10)-Constants.hSpace, letter: "L")
            .environmentObject(KeyboardViewController())
    }
}

struct SquareButtonView: View {
    
    @EnvironmentObject var vc: KeyboardViewController
    @Environment(\.colorScheme) var colorScheme
    
    var letter: String
    var function: () -> Void
    var imageName: String = ""
    var width: CGFloat = 40.0
    
    var body: some View {
        
        Button {
            function()
        } label: {
            if imageName == "number" {
                Text("#+=")
                    .font(.system(size: 12))
                    .frame(width: 40, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
                    .background(colorScheme == .dark ? Color(red: 70.0/255.0, green: 70.0/255.0, blue: 70.0/255.0) : Color(red: 171.0/255.0, green: 177.0/255.0, blue: 186.0/255.0))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
            }
            else if !imageName.isEmpty {
                Image(systemName: imageName)
                    .font(.system(size: Constants.nonLetterFont))
                    .frame(width: 40, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
                    .background(colorScheme == .dark ? Color(red: 70.0/255.0, green: 70.0/255.0, blue: 70.0/255.0) : Color(red: 171.0/255.0, green: 177.0/255.0, blue: 186.0/255.0))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
            }
            else if width != 40.0 {
                SquareTextView(width: width-Constants.hSpace, letter: letter).environmentObject(vc)
                    .foregroundColor(colorScheme == .dark ? .white : .black)
            }
//            else if(letter == "space") {
//                SquareTextView(width: 200, letter: letter).environmentObject(vc)
//                    .foregroundColor(colorScheme == .dark ? .white : .black)
//            }
//            else if(letter == "return") {
//                SquareTextView(width: 86, letter: letter).environmentObject(vc)
//                    .foregroundColor(colorScheme == .dark ? .white : .black)
//            }
            else if(letter == "Hide") {
                Image(systemName: "arrowshape.turn.up.backward.fill")//"arrowshape.left.fill")
                    .font(.system(size: Constants.nonLetterFont))
                    .frame(width: 40, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
                    .background(colorScheme == .dark ? Color(red: 70.0/255.0, green: 70.0/255.0, blue: 70.0/255.0) : Color(red: 171.0/255.0, green: 177.0/255.0, blue: 186.0/255.0))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
            }
            else if (letter == "Send")
            {
                Image(systemName: "paperplane.fill")
                    .font(.system(size: Constants.nonLetterFont))
                    .frame(width: 40, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
                    .background(colorScheme == .dark ? Color(red: 70.0/255.0, green: 70.0/255.0, blue: 70.0/255.0) : Color(red: 171.0/255.0, green: 177.0/255.0, blue: 186.0/255.0))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
            }
            else {
                Text(letter)
                    .font(.system(size: Constants.nonLetterFont))
                    .frame(width: 40, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
                    .background(colorScheme == .dark ? Color(red: 70.0/255.0, green: 70.0/255.0, blue: 70.0/255.0) : Color(red: 171.0/255.0, green: 177.0/255.0, blue: 186.0/255.0))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
            }
        }
        .buttonStyle(.plain)
        .cornerRadius(5)
        .shadow(color: colorScheme == .dark ? .black : .gray, radius: 0, x: 0, y: 1)
    }
}


struct SquareTextView: View {
    var width: CGFloat
    var letter: String
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var vc: KeyboardViewController

    var body: some View {
        Text(letter)
            .font(.system(size: Constants.nonLetterFont))
            .frame(width: width, height: vc.orientation.isPortrait ? Constants.buttonsHeight : Constants.landscapeButtonsHeight)
            .background(letter == "space" ? colorScheme == .dark ? Color(red: 106.0/255.0, green: 106.0/255.0, blue: 106.0/255.0) : .white : colorScheme == .dark ? Color(red: 70.0/255.0, green: 70.0/255.0, blue: 70.0/255.0) : Color(red: 171.0/255.0, green: 177.0/255.0, blue: 186.0/255.0))
            .cornerRadius(5)
    }
}









struct TappablePadding: ViewModifier {
  let insets: EdgeInsets
  let onTap: () -> Void
  
  func body(content: Content) -> some View {
    content
      .padding(insets)
      .contentShape(Rectangle())
      .onTapGesture {
        onTap()
      }
      .padding(insets.inverted)
  }
}

extension View {
  func tappablePadding(_ insets: EdgeInsets, onTap: @escaping () -> Void) -> some View {
    self.modifier(TappablePadding(insets: insets, onTap: onTap))
  }
}

extension EdgeInsets {
  var inverted: EdgeInsets {
    .init(top: -top, leading: -leading, bottom: -bottom, trailing: -trailing)
  }
}
