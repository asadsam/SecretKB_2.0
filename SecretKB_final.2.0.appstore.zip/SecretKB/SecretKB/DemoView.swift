//
//  DemoView.swift
//  SecretKB
//
//  Created by Asadullah Jamadar on 21/12/2023.
//

import SwiftUI

struct DemoView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    DemoView()
}
