//
//  OnboardingPageView.swift
//  SecretKB
//
//  Created by asad on 18/01/2024.
//

import SwiftUI

struct OnboardingPageView: View {
    let imageName: String
    let title: String
    let description: String

    let isFirstScreen: Bool
    let showDoneButton: Bool

    var nextAction: () -> Void

    let backgroundGradient = LinearGradient(
        gradient: Gradient(colors: [Color(hex: "#2aaad5"), Color(hex: "#3f3092")]),
        startPoint: .top, endPoint: .bottom)
    
    var body: some View {
        
        ZStack() {
            backgroundGradient
                            .ignoresSafeArea()
            //GeometryReader { geometry in
                VStack {
                    Spacer()
                    
                    Text(title)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                    
                    //                Text(description)
                    //                    .font(.body)
                    //                    .multilineTextAlignment(.center)
                    //                    //.padding(.horizontal, 40)
                    //                    .foregroundColor(.gray)
                    //                    .padding()
                    
                    if isFirstScreen {
                        Text("Because sometimes, the best hiding place is in the plain sight.")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            //.padding(.top, 20)
                    }
                    
                    GeometryReader { geometry in
                    ZStack(alignment: .center) {
                        Image(imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(15)
                        //.frame(height: geometry.size.height*0.95)
                            //.frame(width: geometry.size.width * 0.75 )
                        //.foregroundColor(.mint)
                            .padding([.leading,.trailing], geometry.size.width*0.10)

                        VStack() {
                            
                            Spacer()
                            
                            if isFirstScreen {
                                Image("appstore")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .cornerRadius(15)
                                    .padding([.leading,.trailing], geometry.size.width*0.20)
                                    .padding(.bottom, 60)

                            }
                            
                            Text(description)
                                .font(.body)
                                .fontWeight(isFirstScreen ? .semibold : .regular)
                                .multilineTextAlignment(.center)
                            //.padding(.horizontal, 40)
                                .foregroundColor(.white)
                                .padding([.leading,.trailing], geometry.size.width*0.20)
                                .padding(.top, -30)
                            
                            if showDoneButton {
                                Button("Done") {
                                    nextAction()
                                }
                                .buttonStyle(PrimaryButtonStyle())
                                //.padding(.top)
                            } else {
                                if isFirstScreen {
                                    Button {
                                        nextAction()
                                    } label: {
                                        HStack() {
                                            Text("Start")
                                            Image(systemName: "arrow.forward")
                                        }
                                }
                                    .buttonStyle(PrimaryButtonStyle())
                                }
                                else {
                                    Button("Next") {
                                        nextAction()
                                    }
                                    .buttonStyle(PrimaryButtonStyle())
                                    //.padding()
                                }
                            }
                            Spacer()
                        }
                    }//.padding()
                    Spacer()
                }
            }//.background(Color.purple)
        }//.background(Color.orange)
        //.ignoresSafeArea()
    }
}

//#Preview {
//    OnboardingPageView(imageName: <#String#>, title: <#String#>, description: <#String#>, showDoneButton: <#Bool#>, nextAction: <#() -> Void#>)
//}



struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.foregroundColor(Color.black)
                    .padding(EdgeInsets(top: 6,
                                           leading: 54,
                                           bottom: 6,
                                           trailing: 54))
                    .background(AnyView(Capsule().fill(Color.white)))//.opacity(0.8)
                       .overlay(RoundedRectangle(cornerRadius: 0).stroke(Color.gray, lineWidth: 0))
        
//        configuration.label
//            .padding(2)
//            .foregroundColor(configuration.isPressed ? Color.red.opacity(0.5) : .red)
//            .overlay(
//                RoundedRectangle(cornerRadius: 8)
//                    .stroke(configuration.isPressed ? Color.red.opacity(0.5) : .red, lineWidth: 1.5)
//            )
     }
}
