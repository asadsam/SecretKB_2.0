//
//  Variable.swift
//  SecretKBExt
//
//  Created by Asadullah Jamadar on 27/06/2023.
//

import Foundation
import Combine
import SwiftUI

let textFieldDidDidBeginEditing = PassthroughSubject<Int, Never>()
let textFieldDidDidEndEditing = PassthroughSubject<Int, Never>()
let enableField = PassthroughSubject<Int, Never>()
let clearField = PassthroughSubject<Int, Never>()
let currentFieldPublisher = PassthroughSubject<Int, Never>()

class Variable:ObservableObject {
  
  @Published var userName = ""
  @Published var password = "" {
      willSet {
        print("WillSet userName ",password.last,newValue.last)
      }
      didSet {
        print("DidSet userName ",password.last,oldValue.last)
  
      }
    }
  static let shared = Variable()
}

//struct ContentView6: View {
//    
//    @ObservedObject var variables = Variable.shared
//    @State var currentField:Int
//    
//    
//    var body: some View {
//        VStack(spacing: 0) {
//            TextFieldView(nameOfField: $variables.userName, currentField: $currentField, fieldID: 123)
//                .onAppear {
//                    enableField.send(123)
//                }
//            TextFieldView(nameOfField: $variables.password, currentField: $currentField, fieldID: 789)
//                .onAppear {
//                    enableField.send(789)
//                }
//        }.onReceive(currentFieldPublisher) { value in
//            currentField = value
//        }
//    }
//}

struct TextFieldView:View, KeyboardReadable {
  
  @State private var isEditing = false
  @State private var isDisabled = true
  
  @Binding var nameOfField: String
  @Binding var currentField: Int
  
  let fieldID: Int!
  
  var body: some View {
     //TextField("Address", text: $nameOfField, axis: .vertical)
      TextField("enter text", text: $nameOfField, onEditingChanged: { (changed) in
      self.isEditing = changed
      if fieldID == currentField {
        textFieldDidDidEndEditing.send(currentField)
      } else {
        textFieldDidDidBeginEditing.send(fieldID)
      }
      currentFieldPublisher.send(fieldID)
    }) {
      currentFieldPublisher.send(0)
      hideKeyboard()
    }.onChange(of: nameOfField) { _ in
//      if nameOfField.last?.asciiValue ?? 0 > 91 {
//        nameOfField.removeLast()
//      }
    }//.border(Color(UIColor.separator))
    .padding()
    .disabled(isDisabled)
    .disableAutocorrection(true)
    .onReceive(keyboardPublisher) { newIsKeyboardVisible in
      print("keyboardVisible ",newIsKeyboardVisible)
    }
    .onReceive(enableField, perform: { value in
      if fieldID == value {
        isDisabled = false
      }
    })
    .onReceive(textFieldDidDidBeginEditing) { value in
        if value == fieldID {
            print("textFieldDidDidBeginEditing ",value)
        }
    }
        .onReceive(textFieldDidDidEndEditing) { value in
          if value == fieldID {
            print("textFieldDidDidEndEditing ",value)
          }
        }
        .onReceive(clearField) { value in
          if value == fieldID {
            nameOfField = ""
          }
        }
        //Text("Your username: \(nameOfField)")
          //.foregroundColor(isEditing ? .red : .blue)
      }
    
    func hideKeyboard() {
    //UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        print("hidekb")
    }
}
