//
//  Utils.swift
//  SecretKBExt
//
//  Created by Asadullah Jamadar on 27/06/2023.
//

import Foundation
import UIKit
import SwiftUI

// MARK: notifications
extension Notification.Name {
    
    static var containerShowAndHideNotification = Notification.Name.init("containerShowAndHideNotification")
    
    static var textProxyForContainer = Notification.Name.init("HandleContainerText")
    
    static var textProxyForContainerSecret = Notification.Name.init("HandleContainerTextSecret")

    static var textProxyNilNotification = Notification.Name.init("TextProxyNilNotification")
    
    // For notifying From Child View Controllers
    static var childVCInformation = Notification.Name.init("ChildVC Information")

}


// MARK: orientation
// Our custom view modifier to track rotation and
// call our action
struct DeviceRotationViewModifier: ViewModifier {
    let action: (UIDeviceOrientation) -> Void

    func body(content: Content) -> some View {
        content
            .onAppear()
            .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
                action(UIDevice.current.orientation)
            }
    }
}

// A View wrapper to make the modifier easier to use
extension View {
    func onRotate(perform action: @escaping (UIDeviceOrientation) -> Void) -> some View {
        self.modifier(DeviceRotationViewModifier(action: action))
    }
}



// MARK: color
extension Color {
    static let lightModeBackgroundColor = Color(red: 208.0/255.0, green: 212.0/255.0, blue: 218.0/255.0)
    static let darkModeBackgroundColor = Color(red: 43.0/255.0, green: 43.0/255.0, blue: 43.0/255.0)
}
