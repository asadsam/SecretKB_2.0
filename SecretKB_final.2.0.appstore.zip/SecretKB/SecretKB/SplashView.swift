//
//  SplashView.swift
//  SwiftUIChangeRootView
//
//  Created by Jaykar Parmar on 02/09/23.
//

import SwiftUI

struct SplashView: View {
    
    @EnvironmentObject private var appRootManager: AppRootManager
    
    let backgroundGradient = LinearGradient(
        gradient: Gradient(colors: [Color(hex: "#2aaad5"), Color(hex: "#3f3092")]),
        startPoint: .top, endPoint: .bottom)
    
    var body: some View {
        ZStack {
            backgroundGradient
                .ignoresSafeArea()
            
            GeometryReader { geometry in
                VStack() {
                    Spacer()
                    Image("appstore")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(15)
                        .padding([.leading,.trailing], geometry.size.width*0.20)
                        .padding(.bottom, 60)
                    
                    Text("Secret Text Keyboard")
                        .font(.title)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    Spacer()
                }
            }
        }
        
        .onAppear() {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                appRootManager.currentRoot = .onBoardingView
            }
        }
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
            .environmentObject(AppRootManager())
    }
}
