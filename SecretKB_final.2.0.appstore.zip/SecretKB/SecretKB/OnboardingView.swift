//
//  OnboardingView.swift
//  SecretKB
//
//  Created by asad on 18/01/2024.
//

import SwiftUI

struct OnboardingView: View {

    @Binding var showOnboarding: Bool
    @State private var selection: Int = 0

    var body: some View {
        TabView(selection: $selection) {
            OnboardingPageView(imageName: "LauncherIcon",
                               title: "Welcome to Secret KB.",
                               description: "Easy steps to setup the keyboard.",
                               isFirstScreen: true, showDoneButton: false,
                               nextAction: goNext)
               .tag(0)

            OnboardingPageView(imageName: "screen1",
                               title: "Step 1",
                               description: "Inside the Settings app - search for SecretKB app and click on it.",
                               isFirstScreen: false, showDoneButton: false,
                               nextAction: goNext)
               .tag(1)

            OnboardingPageView(imageName: "screen2",
                               title: "Step 2",
                               description: "Select 'Keyboards' option.",
                               isFirstScreen: false, showDoneButton: false,
                               nextAction: goNext)
               .tag(2)
            
            OnboardingPageView(imageName: "screen3",
                               title: "Get Set!!!",
                               description: "Turn both the switch buttons ON and you are all set. \n\n(NOTE: We care about your privacy as much as you do. Hence, rest assured, NO DATA is collected or stored whatsoever.)",
                               isFirstScreen: false, showDoneButton: false,
                               nextAction: goNext)
               .tag(3)
            
            OnboardingPageView(imageName: "screen4",
                               title: "GO!!!",
                               description: "You can select the SecretKB keyboard as shown in the picture and use it to send secret messages. HAVE FUN!",
                               isFirstScreen: false, showDoneButton: true,
                               nextAction: {
                showOnboarding = false

            })
              .tag(4)

        }
        .tabViewStyle(.page(indexDisplayMode: .always))
        .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
        .ignoresSafeArea()
    }
    
    func goNext() {
        withAnimation {
            selection += 1
        }
    }
}

#Preview {
    OnboardingView(showOnboarding: .constant(true))
}
