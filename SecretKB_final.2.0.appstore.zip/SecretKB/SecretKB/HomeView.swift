//
//  HomeView.swift
//  SecretKB
//
//  Created by asad on 18/01/2024.
//

import SwiftUI

struct HomeView: View {
    
    @EnvironmentObject private var appRootManager: AppRootManager

    let backgroundGradient = LinearGradient(
        gradient: Gradient(colors: [Color(hex: "#2aaad5"), Color(hex: "#3f3092")]),
        startPoint: .top, endPoint: .bottom)
    
    var body: some View {
        
        ZStack() {
            backgroundGradient
                .ignoresSafeArea()
            
            Button("Repeat") {
                appRootManager.currentRoot = .splash
            }
            .buttonStyle(PrimaryButtonStyle())
        }
    }
}

#Preview {
    HomeView()
}
