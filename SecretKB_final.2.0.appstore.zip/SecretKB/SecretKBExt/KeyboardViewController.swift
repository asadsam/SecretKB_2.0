//
//  KeyboardViewController.swift
//  SecretKBExt
//
//  Created by asad on 22/06/2023.
//

import UIKit
import SwiftUI
import JavaScriptCore
import AudioToolbox

enum InputView {
    case hidden,
    enocdeView,
    decodeView,
    infoView
}

enum NumberPad {
    case numPadNotSelected,
    numPadSelected,
    numPadSelectedWithShift
}

enum SelectedTextField {
    case originalTextField, secretTextField
}

class KeyboardViewController: UIInputViewController, ObservableObject {
    public typealias SubmitHandler = () -> ()
    public typealias SystemFeedbackHandler = () -> ()
    public var onSubmit: SubmitHandler? = nil
    
    internal var keyboardViewController: UIViewController! = nil
    internal var playSystemFeedback: SystemFeedbackHandler? = UIDevice.current.playInputClick
    
    var isShiftSelected: Bool = false
    var numericSelected: Int = 0
    var shiftImageBasedOnNumeric = "capslock"
    @Published var inputViewL: InputView = InputView.hidden

    // textfield
    @Published var currentField: Int = 000
    @State var variablesT = TextfieildsVariable.shared
    @State var orientation = UIDeviceOrientation.portrait

    var encodedText: String = ""
    var decodedText: String = "Plz make sure to 'copy' the text to be decoded and try again."
    var selectedTextField: SelectedTextField = SelectedTextField.originalTextField
    
    var topMostRowArray = ["Encode","Decode"]
    @Published var firstRowArray = "qwertyuiop".map{ String($0) }
    @Published var secondRowArray = "asdfghjkl".map{ String($0) }
    @Published var thirdRowArray = "zxcvbnm".map{ String($0) }
    @Published var fourthRowArray = ["123", "info", "space", "return"]
    
    var jsContext: JSContext!
//    @State var press = false
    //@Environment(\.colorScheme) var colorScheme
    
    var timer: Timer? = Timer()

    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .clear
        
        self.initializeJS()

        // 1
        let vc = UIHostingController(rootView: CustomKeyboardSUI(variablesS: variablesT).environmentObject(self))
        
        let swiftuiView = vc.view!
        swiftuiView.translatesAutoresizingMaskIntoConstraints = false
        
        // 2
        // Add the view controller to the destination view controller.
        //addChild(vc)
        view.addSubview(swiftuiView)
        
        // 3
        // Create and activate the constraints for the swiftui's view.
        NSLayoutConstraint.activate([
        swiftuiView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        swiftuiView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        swiftuiView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // 4
        // Notify the child view controller that the move is complete.
        vc.didMove(toParent: self)
    }
    
    
    //
    func keyPressed() {
        playSystemFeedback?()
    }
    
    func addToCurrentWordK(_ letter: String) {
        print("current word \(letter)")
        //playSystemFeedback?()

        DispatchQueue.main.async {
            AudioServicesPlaySystemSound(0x450);
        }
        
        if currentField == 111 {
            variablesT.visible = variablesT.visible + letter
        }
        else if currentField == 222 {
            variablesT.hidden = variablesT.hidden + letter
        }
        else {
            
            //DispatchQueue.main.async {
                   self.textDocumentProxy.insertText("\(letter)")}
            
            //self.textDocumentProxy.insertText("\(letter)")
        //}
    }
    
    func shiftButtonClicked() {
        
        if numericSelected != 0 {
            if numericSelected == 1 {
                firstRowArray = "[]{}#%^*+=".map{ String($0) }
                secondRowArray = "_\\|~<>€£¥•".map{ String($0) }
                    
                thirdRowArray = ".,?!'".map{ String($0) }
                
                numericSelected = 2
                shiftImageBasedOnNumeric = "textformat.123"
            }
            else if numericSelected == 2 {
                
                firstRowArray = "1234567890".map{ String($0) }
                secondRowArray = "-/:;()$&@”".map{ String($0) }
                thirdRowArray = ".,?!'".map{ String($0) }
                
                numericSelected = 1
                shiftImageBasedOnNumeric = "number"
            }
            
        }
        else if isShiftSelected {
            firstRowArray = "qwertyuiop".map{ String($0) }
            secondRowArray = "asdfghjkl".map{ String($0) }
            thirdRowArray = "zxcvbnm".map{ String($0) }
            
            isShiftSelected = false
            shiftImageBasedOnNumeric = "capslock"
        }
        else {
            firstRowArray = "QWERTYUIOP".map{ String($0) }
            secondRowArray = "ASDFGHJKL".map{ String($0) }
            thirdRowArray = "ZXCVBNM".map{ String($0) }
            
            isShiftSelected = true
            shiftImageBasedOnNumeric = "capslock.fill"
        }
    }
    
    func numericButtonClicked() {

        if numericSelected == 0 {
            numericSelected = 1
            
            firstRowArray = "1234567890".map{ String($0) }
            secondRowArray = "-/:;()$&@”".map{ String($0) }
            thirdRowArray = ".,?!'".map{ String($0) }
            
            
            shiftImageBasedOnNumeric = "number"
        }
        else {
            numericSelected = 0
            
//            firstRowArray = "QWERTYUIOP".map{ String($0) }
//            secondRowArray = "ASDFGHJKL".map{ String($0) }
//            thirdRowArray = "ZXCVBNM".map{ String($0) }
            
            firstRowArray = "qwertyuiop".map{ String($0) }
            secondRowArray = "asdfghjkl".map{ String($0) }
            thirdRowArray = "zxcvbnm".map{ String($0) }
            
            isShiftSelected = false
            shiftImageBasedOnNumeric = "capslock"
        }
    }
    
    func configureButtons() {
        
    }
    
    func deleteBackwardsButtonClicked() {
        if currentField == 111 {
            variablesT.visible = String.init((variablesT.visible.dropLast()))
        }
        else if currentField == 222 {
            variablesT.hidden = String.init((variablesT.hidden.dropLast()))
        }
        else {
            DispatchQueue.main.async {
                self.textDocumentProxy.deleteBackward()}
        }
    }
    
    @objc func onLongPressOfBackSpaceKey() {
        
        //switch longGestr.state {
        //case .began:
            if currentField == 111 {
                variablesT.visible = String.init((variablesT.visible.dropLast()))
            }
            else if currentField == 222 {
                variablesT.hidden = String.init((variablesT.hidden.dropLast()))
            }
            else {
                DispatchQueue.main.async {
                    self.textDocumentProxy.deleteBackward()}
            }
            
//        case .ended:
//            print("Ended")
//            return
//        default:
//            self.textDocumentProxy.deleteBackward()
//            //deleteLastWord()
//        }
        
    }
    
    func infoButtonClicked() {
        self.inputViewL = InputView.infoView
    }
    
    func globeButtonClicked() {
        advanceToNextInputMode()
    }
    
    func spaceButtonClicked() {
        DispatchQueue.main.async {
            self.addToCurrentWordK(" ")
        }
    }
    
    func returnButtonClicked() {
        DispatchQueue.main.async {
            self.addToCurrentWordK("\n")
        }
    }
    
    func encodeClicked() {
        if self.inputViewL == InputView.enocdeView { return }

        self.inputViewL = InputView.enocdeView
    }
    
    func decodeClicked() {
        //if self.inputViewL == InputView.decodeView { return }
        
        let pasteboard: UIPasteboard = UIPasteboard.general
        let array: Array = pasteboard.types
        
        for type in array {
            print(type)
            print(UIPasteboard.general.string ?? "nothing on pasteboard")

            //if(type == "public.utf8-plain-text"){
                if(UIPasteboard.general.string != nil) {
                    //self.decodeT(strToDecode: UIPasteboard.general.string!)
                    //self.decrypt()
                    self.decodeNew(strToDecode: UIPasteboard.general.string!)
                }
            else {
                self.decodedText = "Plz make sure to 'copy' the text to be decoded and try again."
            }
            //}
        }
        
        self.inputViewL = InputView.decodeView
    }
    
    func hideButtonClicked() {
        currentFieldPublisher.send(0)
        self.inputViewL = InputView.hidden
    }
    
    func sendButtonClicked() {
        if variablesT.visible.isEmpty {return}
        
        if variablesT.hidden.isEmpty {
            self.textDocumentProxy.insertText(variablesT.visible)
        }
        else {
            // encode and send to the real text field
            self.encodeNew()
            self.textDocumentProxy.insertText(self.encodedText)
        }
        
        variablesT.visible = ""
        variablesT.hidden = ""
        
        currentFieldPublisher.send(0)
        //variablesT.hidden.endEditing()
        self.inputViewL = InputView.hidden
    }
    
    
    //
    private let consoleLog: @convention(block) (String) -> Void = { logMessage in
        //print("\nJS Console:", logMessage)
    }
}
    
extension KeyboardViewController {
    
    func initializeJS() {
        self.jsContext = JSContext()

        // Add an exception handler.
        self.jsContext.exceptionHandler = { context, exception in
            if let exc = exception {
                print("JS Exception:", exc.toString())
            }
        }

        // Specify the path to the jssource.js file.
        if let jsSourcePath = Bundle.main.path(forResource: "Steganography", ofType: "js") {
            do {
                // Load its contents to a String variable.
                let jsSourceContents = try String(contentsOfFile: jsSourcePath)

                // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
                print(error.localizedDescription)
            }
        }


        let consoleLogObject = unsafeBitCast(self.consoleLog, to: AnyObject.self)
        self.jsContext.setObject(consoleLogObject, forKeyedSubscript: "consoleLog" as (NSCopying & NSObjectProtocol))
        _ = self.jsContext.evaluateScript("consoleLog")
    }
    
    

    func encrypt() {
//        if let encodetxt = self.jsContext.objectForKeyedSubscript("encode") {
//            // Call the function that composes the fullname.
//            if let fullname = encodetxt.call(withArguments: [self.originalText]) {
//                print(fullname.toString() ?? "bla bla bla")
//                encodedText = fullname.toString()
//            }
//        }
        
        
        if let encodetxt = self.jsContext.objectForKeyedSubscript("encode") {
            // Call the function that composes the fullname.
            if let fullname = encodetxt.call(withArguments: [variablesT.hidden]) {
                print(fullname.toString() ?? "bla bla bla")
                encodedText = fullname.toString()
                
                encodedText = encodedText+self.variablesT.visible
            }
        }
    }
    
    func decrypt() {
        if let encodetxt = self.jsContext.objectForKeyedSubscript("reveal") {
            // Call the function that composes the fullname.
            if let fullname = encodetxt.call(withArguments: [encodedText, "james"]) {
                print(fullname.toString() ?? "bla bla bla")
                encodedText = fullname.toString()
            }
        }
        
//        if let decodetxt = self.jsContext.objectForKeyedSubscript("decode") {
//            // Call the function that composes the fullname.
//            if let resultDecodedText = decodetxt.call(withArguments: [UIPasteboard.general.string]) {
//                print(resultDecodedText.toString() ?? "bla bla bla")
//                self.decodedText = resultDecodedText.toString()
//            }
//
//        }
    }
    
    func encodeNew() {
        if let encodetxt = self.jsContext.objectForKeyedSubscript("encode") {
            // Call the function that composes the fullname.
            if let fullname = encodetxt.call(withArguments: [variablesT.hidden]) {
                print(fullname.toString() ?? "bla bla bla")
                encodedText = fullname.toString()
                
                encodedText = encodedText+variablesT.visible
                print("encodedtext = \(self.encodedText)")
            }
        }
    }
    
    func decodeNew(strToDecode: String) {
        if let decodetxt = self.jsContext.objectForKeyedSubscript("decode") {
            // Call the function that composes the fullname.
            if let resultDecodedText = decodetxt.call(withArguments: [strToDecode]) {
                print(resultDecodedText.toString() ?? "bla bla bla")
                                
                if !resultDecodedText.toString().isEmpty {
                    self.decodedText = resultDecodedText.toString()
                    print("decodetxt = \(self.decodedText)")
                }
                else {
                    self.decodedText = "No hidden message found!!"
                    print("decodetxt = \(self.decodedText)")
                }
            }
            
        }
    }
    
    func encodeT(tf1: String, tf2: String) {
        
        if let encodetxt = self.jsContext.objectForKeyedSubscript("encodeText123") {
            // Call the function that composes the fullname.
            if let fullname = encodetxt.call(withArguments: [tf1, tf2]) {
                print(fullname.toString() ?? "bla bla bla")
                encodedText = fullname.toString()
            }
        }
            
//        let data = Data(tf2.utf8)
////        data = tf2.data(using: .utf8) ?? "default string".data(using: .utf8) as! Data
//
//        var received: [UInt8] = []
//        received = Array(data)
//
//        if let encodetxt = self.jsContext.objectForKeyedSubscript("encodeBinary") {
//            // Call the function that composes the fullname.
//            if let fullname = encodetxt.call(withArguments: [tf1, received]) {
//                print(fullname.toString() ?? "bla bla bla")
//                encodedText = fullname.toString()
//            }
//        }
    }
    
    func decodeT(strToDecode: String) {
        if let decodetxt = self.jsContext.objectForKeyedSubscript("decodeText123") {
            // Call the function that composes the fullname.
            if let resultDecodedText = decodetxt.call(withArguments: [strToDecode]) {
                
//                self.decodedText = resultDecodedText.toString()
//                if(self.decodedText.isEmpty) {
//                    self.decodedText = "Looks like the copied Text is unencoded!!!"
//                }
                if let resultsDict = resultDecodedText.toDictionary() {
                    for (key, value) in resultsDict {
                        print(key, value)
                    }
                    self.decodedText = resultsDict["hiddenText"] as! String

                    if(self.decodedText.isEmpty) {
                        self.decodedText = "Looks like the copied Text is unencoded!!!"
                    }
                }
            }
        }
        
//        if let decodetxt = self.jsContext.objectForKeyedSubscript("decodeBinary") {
//            // Call the function that composes the fullname.
//            if let resultDecodedText = decodetxt.call(withArguments: [strToDecode]) {
//                if let resultsDict = resultDecodedText.toDictionary() {
//                    for (key, value) in resultsDict {
//                        print(key, value)
//                    }
//
//                    let dict = resultsDict["hiddenData"] //String(decoding: resultsDict["hiddenData"] as! Dictionary, as: UTF8.self)
//
////                    let arrValue: [UInt8] = resultsDict["hiddenData"] as! [UInt8]
////                    let arrData = Data(arrValue)
////
////                    //Data to [UInt8]
////                    let originalValues = Array(arrData)
////                    print(originalValues) //->[123,234]
//
//
//                    //self.decodedText = dict["hiddenText"]//resultsDict["hiddenData"] as! String
//
//                    if(self.decodedText.isEmpty) {
//                        self.decodedText = "Looks like the copied Text is unencoded!!!"
//                    }
//                }
//            }
//        }
        
        
    }
}

//extension KeyboardViewController: UITextFieldDelegate, UITextViewDelegate {
//    // Assign the newly active text field to your activeTextField variable
//    func textFieldDidBeginEditing(_ textField: UITextField) {
//
//            self.activeTextField = textField
//
//            print("textField - %@", textField.description)
//
//            NotificationCenter.default.post(name: .childVCInformation, object: "originaltextfield")
//
//       }
//
//    func textFieldShouldClear(_ textField: UITextField) -> Bool {
//        print("text cleared")
//        //do few custom activities here
//
//        self..text = ""
//        NotificationCenter.default.post(name: .textProxyNilNotification, object: "originaltextfield")
//
//        return true
//      }
//
//
//    // Assign the newly active text field to your activeTextField variable
//    func textViewDidBeginEditing(_ textView: UITextView)  {
//
//        NotificationCenter.default.post(name: .childVCInformation, object: "secrettextfield")
//
//        if secretTextView.textColor == UIColor.darkGray {
//            secretTextView.text = nil
//
//            switch traitCollection.userInterfaceStyle {
//                    case .light, .unspecified:
//                        // light mode detected
//                        secretTextView.textColor = UIColor.black
//
//                    case .dark:
//                        // dark mode detected
//                        secretTextView.textColor = UIColor.white
//
//            @unknown default:
//                secretTextView.textColor = UIColor.black
//
//            }
//            }
//
//        print("textView - %@", textView.description)
//
//       }
//
//    func textViewDidEndEditing(_ textView: UITextView) {
//
//        if secretTextView.text.isEmpty {
//            secretTextView.text = "Secret Text"
//            secretTextView.textColor = UIColor.darkGray
//        }
//    }
//
//    func textViewShouldClear(_ textView: UITextView) -> Bool {
//        print("textview cleared")
//        //do few custom activities here
//
//        self.secretTextView.text = ""
//        NotificationCenter.default.post(name: .textProxyNilNotification, object: "secrettextfield")
//
//        if secretTextView.text.isEmpty {
//                secretTextView.text = "Secret Text"
//                secretTextView.textColor = UIColor.darkGray
//            }
//
//        return true
//      }
//}

/*
 UIInputViewController, ObservableObject {
 
 override func updateViewConstraints() {
 super.updateViewConstraints()
 
 // Add custom view sizing constraints here
 }
 
 override func viewDidLoad() {
 super.viewDidLoad()
 
 // 1
 let vc = UIHostingController(rootView: CustomKeyboardSUI())
 
 let swiftuiView = vc.view!
 swiftuiView.translatesAutoresizingMaskIntoConstraints = false
 
 // 2
 // Add the view controller to the destination view controller.
 addChild(vc)
 view.addSubview(swiftuiView)
 
 // 3
 // Create and activate the constraints for the swiftui's view.
 NSLayoutConstraint.activate([
 swiftuiView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
 swiftuiView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
 ])
 
 // 4
 // Notify the child view controller that the move is complete.
 vc.didMove(toParent: self)
 
 }
 
 override func viewWillLayoutSubviews() {
 // self.nextKeyboardButton.isHidden = !self.needsInputModeSwitchKey
 super.viewWillLayoutSubviews()
 }
 
 override func textWillChange(_ textInput: UITextInput?) {
 // The app is about to change the document's contents. Perform any preparation here.
 }
 
 override func textDidChange(_ textInput: UITextInput?) {
 // The app has just changed the document's contents, the document context has been updated.
 
 //        var textColor: UIColor
 //        let proxy = self.textDocumentProxy
 //        if proxy.keyboardAppearance == UIKeyboardAppearance.dark {
 //            textColor = UIColor.white
 //        } else {
 //            textColor = UIColor.black
 //        }
 // self.nextKeyboardButton.setTitleColor(textColor, for: [])
 }
 
 
 func addToCurrentWordK(_ letter: String) {
 print("current word \(letter)")
 
 //let proxy = self.textDocumentProxy
 //self.textDocumentProxy.insertText("\(letter)")
 let proxy = self.textDocumentProxy
 self.textDocumentProxy.insertText("\(letter)")
 //        (self.textDocumentProxy as UIKeyInput).insertText("Hello World!")
 //        (self.textDocumentProxy as UITextDocumentProxy as UIKeyInput).insertText("Hello World!")
 
 
 }
 
 }
 */
