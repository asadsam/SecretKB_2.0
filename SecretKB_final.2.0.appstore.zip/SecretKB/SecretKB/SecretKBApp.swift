//
//  SecretKBApp.swift
//  SecretKB
//
//  Created by asad on 22/06/2023.
//

import SwiftUI

@main
struct SecretKBApp: App {
    @StateObject private var appRootManager = AppRootManager()

    var body: some Scene {
        WindowGroup {
            Group {
                switch appRootManager.currentRoot {
                case .splash:
                    SplashView()
                    
                case .onBoardingView:
                    ContentView()
                        .transition(.scale.animation(.easeInOut(duration: 0.5)))
                    
                case .home:
                    HomeView()
                        .transition(.scale.animation(.easeInOut(duration: 0.5)))
                }
            }
            .environmentObject(appRootManager)
        }
    }
}

final class AppRootManager: ObservableObject {
    
    @Published var currentRoot: eAppRoots = .splash
    
    enum eAppRoots {
        case splash
        case onBoardingView
        case home
    }
}
