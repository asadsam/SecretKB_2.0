//
//  CustomKeyboardSUI.swift
//  SecretKBExt
//
//  Created by asad on 22/06/2023.
//

import SwiftUI

class TextfieildsVariable:ObservableObject {
  
  @Published var visible = ""
  @Published var hidden = "" {
      willSet {
        print("WillSet userName ",visible.last,newValue.last)
      }
      didSet {
        print("DidSet userName ",hidden.last,oldValue.last)
  
      }
    }
  static let shared = TextfieildsVariable()
}

struct CustomKeyboardSUI: View {
    
    @EnvironmentObject var dm: KeyboardViewController
    //@State var visibleText: String = ""
    //@State var hiddenText: String = ""
    var notificationDictionary = [String: Any]()

    @State var visibleText: String = "" {
        
        mutating didSet{
            //if(self.isContainerShowing) {
                self.notificationDictionary["txt"] = self.visibleText
            NotificationCenter.default.post(name: .textProxyForContainer, object: nil, userInfo: self.notificationDictionary)
            //}
        }
    }
    
    @State var hiddenText: String = "" {
        
        mutating didSet{
            //if(self.isContainerShowing) {
                self.notificationDictionary["txt"] = self.hiddenText
            NotificationCenter.default.post(name: .textProxyForContainerSecret, object: nil, userInfo: self.notificationDictionary)
            //}
        }
    }
    
    @ObservedObject var variablesS: TextfieildsVariable
    @GestureState var press = false
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        
        ZStack {
            if colorScheme == .dark {
                Color.darkModeBackgroundColor
                    .ignoresSafeArea()
            }
            else {
                Color.lightModeBackgroundColor
                    .ignoresSafeArea()
            }
            
            VStack(spacing: Constants.vSpace) {
                
                if dm.inputViewL == InputView.hidden {
                    // first row
                    //VStack(spacing: 5) {
                    //Spacer()
                    
                    HStack(spacing: Constants.hSpace) {
                        SquareButtonView(letter: "Encode", function: dm.encodeClicked, imageName: "" /*"lock.fill"*/, width: 150.0)
                            .environmentObject(dm)
                        
                        Spacer()
//                        Text("SK")
//                            //.font(.system(size: 15))
//                            .font(Font.system(.subheadline, design: .rounded))
//                            .frame(height: 40)
//                            .foregroundColor(colorScheme == .dark ? .white : .black)
//                        Image(systemName: "keyboard")
//                            .resizable()
//                            .frame(width: 25,height: 20,alignment: .center)
//                            .cornerRadius(5.0)
//                            .opacity(0.7)
//                            //.padding()
//                        
//                        Spacer()
                        
                        SquareButtonView(letter: "Decode", function: dm.decodeClicked, imageName: "" /*"lock.open.fill"*/, width: 150.0)
                            .environmentObject(dm)
                    }
                    //.padding()//([.leading,.trailing], 6)
                    .padding([.top, .leading, .trailing], 8)
                }
                else if dm.inputViewL == InputView.enocdeView {
                    HStack(spacing: Constants.hSpace) {
                        
                        //HStack(spacing: 4) {
                        
                        SquareButtonView(letter: "Hide",  function: dm.hideButtonClicked, imageName: "xmark")
                            .environmentObject(dm)
                        
                        VStack(spacing: -2) {
                            Text("Visible Text:")
                                .font(.system(size: 12))
                                .frame(height: 20)
                                .foregroundColor(.primary)
                            
                            TextFieldView(nameOfField: $variablesS.visible, currentField: $dm.currentField, fieldID: 111)
                                .font(.system(size: 18))
                                .frame(height: 35)
                                //.lineLimit(5...10)
                                .foregroundColor(.black)
                                .background(RoundedRectangle(cornerRadius: 10.0).fill(Color.white))
                                .overlay(RoundedRectangle(cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                                .onAppear {
                                    enableField.send(111)
                                }
                        }
                        
                        VStack(spacing: -2) {
                            Text("Hidden Text:")
                                .font(.system(size: 12))
                                .frame(height: 20)
                                .foregroundColor(.primary)
                            
                            
                            TextFieldView(nameOfField: $variablesS.hidden, currentField: $dm.currentField, fieldID: 222)
                                .font(.system(size: 18))
                                .frame(height: 35)
                                //.lineLimit(5...10)
                                .foregroundColor(.black)
                                .background(RoundedRectangle(cornerRadius: 10.0).fill(Color.white))
                                .overlay(RoundedRectangle(cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                                .onAppear {
                                    enableField.send(222)
                                }
                        }.onReceive(currentFieldPublisher) { value in
                            dm.currentField = value
                        }
                        //}
                        
                        
                        SquareButtonView(letter: "Send",  function: dm.sendButtonClicked, imageName: "checkmark")
                            .environmentObject(dm)
                    }
                    //.padding()
                    //.padding([.leading,.trailing], 11)
                }
                else if dm.inputViewL == InputView.infoView {
                    
                    HStack(spacing: Constants.hSpace) {
                        /*SquareButtonView(letter: "Encode", function: dm.encodeClicked, imageName: "" /*"lock.fill"*/, width: 40.0)
                            .environmentObject(dm)*/
                    
                    SquareButtonView(letter: "Hide",  function: dm.hideButtonClicked, imageName: "arrowshape.turn.up.backward")
                        .environmentObject(dm)
                        
                        Spacer()
                        Text("write to us at - asad.james@gmail.com")
                            .font(.system(size: 15))
                            .frame(height: 40)
                            .foregroundColor(.blue)
                        Spacer()
                        
                        /*SquareButtonView(letter: "Decode", function: dm.decodeClicked, imageName: "" /*"lock.open.fill"*/, width: 40.0)
                            .environmentObject(dm)*/
                    }
                    .padding([.leading, .trailing], 11)
                }
                else if dm.inputViewL == InputView.decodeView { //here come the decoded text view
                    
                    HStack(spacing: Constants.hSpace) {
                        /*SquareButtonView(letter: "Encode", function: dm.encodeClicked, imageName: "" /*"lock.fill"*/, width: 40.0)
                            .environmentObject(dm)*/
                        
                        SquareButtonView(letter: "Hide",  function: dm.hideButtonClicked, imageName: "arrowshape.turn.up.backward")
                            .environmentObject(dm)
                        
                        Spacer()
                        if dm.decodedText.count > 30 {
//                            BlockTextAnimation(text: dm.decodedText, font: .system(size: 15), startTime: 1.0)
                            ScrollView {
                                Text(dm.decodedText)
                                    .font(.system(size: 13))
                                                .lineLimit(nil)
                                                .frame(width: 260)
                                                .foregroundColor(colorScheme == .dark ? Color.white : Color.black)
                                        }
                        }
                        else {
                            BlurView(text: dm.decodedText, textSize: 15, startTime: 0.15)
                                .font(.system(size: 15))
                                .frame(height: 50)
                                .foregroundColor(colorScheme == .dark ? Color.white : Color.black)
                        }
                        Spacer()
                        
                        /*SquareButtonView(letter: "Decode", function: dm.decodeClicked, imageName: "" /*"lock.open.fill"*/, width: 40.0)
                            .environmentObject(dm)*/
                    }
                    .padding([.leading, .trailing], 11)
                }
                
                // second row
                HStack(spacing: Constants.hSpace) {
                    ForEach(dm.firstRowArray, id: \.self) { letter in
                        LetterButtonView(width: (dm.orientation.isPortrait ? (Constants.portraitWidth+Constants.hSpace)/10 : Constants.landscapeWidth/10)-(Constants.hSpace/2), letter: letter)
                            .environmentObject(dm)
                    }
                }
                
                // third row
                HStack(spacing: Constants.hSpace) {
                    ForEach(dm.secondRowArray, id: \.self) { letter in
                        LetterButtonView(width: (dm.orientation.isPortrait ? (Constants.portraitWidth+Constants.hSpace)/10 : Constants.landscapeWidth/10)-(Constants.hSpace/2), letter: letter)
                            .environmentObject(dm)
                    }
                }
                
                // fourth row
                HStack(spacing: Constants.hSpace) {
                    SquareButtonView(letter: "shift.fill", function: dm.shiftButtonClicked, imageName: /*if dm.isShiftSelected && dm.numericSelected == 1 {"#"}*/ /*dm.isShiftSelected ? "capslock.fill" : "capslock"*/ dm.shiftImageBasedOnNumeric)
                        .padding(.leading, Constants.hSpace+4)
                        .environmentObject(dm)
                    Spacer()
                    ForEach(dm.thirdRowArray, id: \.self) { letter in
                        LetterButtonView(width: (dm.orientation.isPortrait ? (Constants.portraitWidth+Constants.hSpace)/10 : Constants.landscapeWidth/10)-(Constants.hSpace/2), letter: letter)
                            .environmentObject(dm)
                        
                    }
                    Spacer()
                    
                    SquareButtonView(letter: "delete.backward.fill", function: dm.deleteBackwardsButtonClicked, imageName: "delete.backward.fill")
                        .padding(.trailing, Constants.hSpace+4)
                        .environmentObject(dm)
                        .simultaneousGesture(
                            LongPressGesture()
                                .onEnded { _ in
                                    dm.timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
                                        dm.onLongPressOfBackSpaceKey()
                                    }
                                }
                                .sequenced(
                                    before: DragGesture(minimumDistance: 0)
                                        .onEnded { _ in
                                            dm.timer?.invalidate()
                                            dm.timer = nil
                                        }
                                )
                            )
                }
                
                // fifth row
                HStack(spacing: Constants.hSpace) {
                    SquareButtonView(letter: (dm.numericSelected == 0) ? "textformat.123" : "textformat.abc", function: dm.numericButtonClicked, imageName: (dm.numericSelected == 0) ? "textformat.123" : "textformat.abc")
                        .environmentObject(dm)
                    
                    SquareButtonView(letter: "info.circle",  function: dm.infoButtonClicked, imageName: "info.circle")
                        .environmentObject(dm)
                    
                    SquareButtonView(letter: "globe",  function: dm.globeButtonClicked, imageName: "globe")
                        .environmentObject(dm)
                    
                    //TODO: width calculation as per view.bounds
                    SquareButtonView(letter: "space", function: dm.spaceButtonClicked, width: (dm.orientation.isPortrait ? Constants.portraitWidth/10 : Constants.landscapeWidth/10)*5-(Constants.hSpace*2)/*170.0*/)
                        .environmentObject(dm)
                    
                    //TODO: width calculation as per view.bounds
                    SquareButtonView(letter: "return",  function: dm.returnButtonClicked, width: (dm.orientation.isPortrait ? Constants.portraitWidth/10 : Constants.landscapeWidth/10)*2-(Constants.hSpace*2)/*72.0*/)
                        .environmentObject(dm)
                }
                //.padding([.leading,.trailing], 6)
            }
            
            
        }
        .padding(.top, 4)
        .padding(.bottom, 4)
        .background(colorScheme == .dark ? Color.darkModeBackgroundColor : Color.lightModeBackgroundColor)//(Color.clear)//(Color(red: 43.0/255.0, green: 43.0/255.0, blue: 43.0/255.0))
        
        .onRotate { newOrientation in
            dm.orientation = newOrientation
                }
    }
}

struct CustomKeyboardSUI_Previews: PreviewProvider {
    
    static var previews: some View {
        CustomKeyboardSUI(variablesS: TextfieildsVariable())
    }
}

struct BlurView: View {
    let characters: Array<String.Element>
    let baseTime: Double
    let textSize: Double
    @State var blurValue: Double = 10
    @State var opacity: Double = 0
    
    init(text:String, textSize: Double, startTime: Double) {
        characters = Array(text)
        self.textSize = textSize
        baseTime = startTime
    }
    
    var body: some View {
        
        HStack(spacing: 1){
            ForEach(0..<characters.count) { num in
                Text(String(self.characters[num]))
                    //.fixedSize(horizontal: false, vertical: true)
                    //.font(.custom("HiraMinProN-W3", fixedSize: textSize))
                    .blur(radius: blurValue)
                    .opacity(opacity)
                    .animation(.easeInOut.delay( Double(num) * 0.05 ),
                               value: blurValue)

            }
        }.onTapGesture {
            if blurValue == 0 {
                blurValue = 10
                opacity = 0.01
            } else {
                blurValue = 0
                opacity = 1
            }
        }
        .onAppear{
            DispatchQueue.main.asyncAfter(deadline: .now() + baseTime) {
                if blurValue == 0{
                    blurValue = 10
                    opacity = 0.01
                } else {
                    blurValue = 0
                    opacity = 1
                }
            }
        }
    }
}


struct BlockTextAnimation: View {
    let characters: Array<String.Element>
    var font: Font
    
    @State var rectHeight: CGFloat = 0.1
    @State var pathWidth: CGFloat = 100
    @State var pathHeight: CGFloat = 100  // Displayed on preview mode
//    @State var rectOffsetX: CGFloat = 0
    
    @State var rectScale: Double = 0.0
    @State var rectAnchor: UnitPoint = .leading
    
    @State var textOpacity: Double = 0.0
    
    var baseTime: Double = 1.0
    
    init(text: String, font: Font, startTime: Double) {
        self.characters = Array(text)
        self.font = font
        self.baseTime = startTime
    }
    
    var body: some View {
        ZStack {
            ScrollView {
                Text(String(characters))
                    .font(font)
                    .opacity(textOpacity)
                    .background(GeometryReader{ geometry -> Text in
                        // NavigationLink
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                            rectHeight = geometry.frame(in: .local).height
                            pathWidth = geometry.frame(in: .local).width
                            pathHeight = geometry.frame(in: .local).height
                        }
                        return Text("")
                    })
                
                Rectangle()
                //                .offset(x: rectOffsetX, y: 0)
                    .scale(x: rectScale, y: 1, anchor: rectAnchor)
                    .frame(width: pathWidth, height: pathHeight, alignment: .center)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1 + baseTime) {
                            withAnimation(.easeInOut) {
                                rectScale = 1
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5 + baseTime) {
                            textOpacity = 1.0
                            rectAnchor = .trailing
                            withAnimation(.easeInOut){
                                rectScale = 0.0
                            }
                        }
                    }
            }
        }
        .onTapGesture {
            blockAnimation()
        }
    }
    
    func blockAnimation(){
        rectAnchor = .leading
        textOpacity = 0.0
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.easeInOut) {
                rectScale = 1
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            textOpacity = 1.0
            rectAnchor = .trailing
            withAnimation(.easeInOut){
                rectScale = 0.0
            }
        }
    }
}
