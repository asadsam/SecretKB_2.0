//
//  ContentView.swift
//  SecretKB
//
//  Created by asad on 22/06/2023.
//

import SwiftUI

struct ContentView: View {
    @State var showOnboarding: Bool = true

        var body: some View {
            //TabView {
                //NavigationStack {
                    HomeView()
                        .navigationTitle("Home")
                //}
//                .tabItem {
//                    Label("Tab 1", systemImage: "1.circle")
//                }
//
//                SettingsView()
//                    .tabItem {
//                        Label("Settings", systemImage: "gear")
//                    }
//            }
            #if os(iOS)
            .fullScreenCover(isPresented: $showOnboarding, content: {
                OnboardingView(showOnboarding: $showOnboarding)
            })
            #else
            .sheet(isPresented: $showOnboarding) {
                OnboardingView(showOnboarding: $showOnboarding)
            }
            #endif
        }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//struct ContentView: View {
//    
//    @State var isPresented: Bool = false
//    @State private var isExpanded: Bool = false
//
//    var body: some View {
////        ZStack(alignment: .bottomTrailing) {
////            Image("secretagent")
////                .resizable()
////                .opacity(0.2)
////                .padding(.leading, 40)
////                .padding(.trailing, 40)
////            
////                .padding(.top, 120)
////                .padding(.bottom, 120)
//            
//            VStack {
//                Spacer().frame(height: 52)
//                VStack(alignment: .leading, spacing: 05) {
//                    Text("Secret Text Keyboard - 007")
//                        .font(.system(size: 25, weight: .bold))
//                        .foregroundColor(.primary)
//                    Text("Sometimes the best hiding place is the one that's in plain sight!!!")
//                        .font(.primary(.regular, size: 16))
//                        .foregroundColor(.secondary)
//                        .lineSpacing(10.0)
//                }
//                
//                
//                
//                //            ZStack(alignment: .bottomTrailing) {
//                //                Image("secretagent")
//                //                    .resizable()
//                //                    .opacity(0.3)
//                //                    .padding(.leading, 40)
//                //                    .padding(.trailing, 40)
//                //
//                //                    .padding(.top, 80)
//                //                    .padding(.bottom, 120)
//                
//                //.edgesIgnoringSafeArea(.bottom)
//                //.font(.system(size: 128, weight: .ultraLight))
//                //.background(DiamondBackground())
//                
//                VStack(alignment: .leading, spacing: 20) {
//                    Spacer().frame(height: 6)
//                    Text("Setup:")
//                        .font(.system(size: 20, weight: .bold, design: .default))
//                    //.font(Font.headline.weight(.bold))
//                        .foregroundColor(.secondary)
//                        .padding(.leading)
//                    
//                    
//                    VStack(alignment: .leading) {
//                        
//                        SetUpStepsView(stepText: "Open the Settings App")
//                        SetUpStepsView(stepText: "Go to General -> Keyboard -> Keyboards -> Add New Keyboard...")
//                        SetUpStepsView(stepText: "Select Sceret Text Keyboard")
//                        SetUpStepsView(stepText: "Now click on this added  keyboard and allow full access")
//                        
//                    }.padding([.top, .bottom])
//                        .background(DiamondBackground())
//                    
//                    Text("Note: We do not read, record or transmit anything you type. Every process is done offline and does not require any network connection. \n*Should be used  for entertainment purposes only.")
//                        .font(.primary(.medium, size: 14))
//                        .foregroundColor(.primaryRed)
//                        .lineSpacing(5.0)
//                    //                        .padding(.leading)
//                    //                        .padding(.trailing)
//                    //                        .padding(.bottom)
//                        .padding()
//                    //.lineLimit(4)
//                        .overlay(
//                            GeometryReader { proxy in
//                                Button(action: {
//                                    
//                                    isExpanded.toggle()
//                                })
//                                {
//                                    Text("Learn More")
//                                        .font(.caption).bold()
//                                        .padding(.leading, 8.0)
//                                        .padding(.top, 4.0)
//                                        .background(Color.clear)
//                                        .foregroundColor(Color.blue)
//                                }
//                                .alert(isPresented: $isExpanded) {
//                                    Alert(title: Text("Hello There!!"), message: Text("We do not read, record or transmit anything you type on the keyboard. Every process is done offline and inside the keyboard app itself and does not require any network connection. \nWe take pride in letting you know that we are as concerned about your privacy as you are."), dismissButton: .default(Text("Get Going, Enjoy!")))
//                                } //This app just gets the copied text from clipboard and decodes it for you.
//                                .frame(width: proxy.size.width-20, height: proxy.size.height, alignment: .bottomTrailing)
//                                
//                            }
//                        )
//                    
//                    Text("How to use:")
//                        .font(.system(size: 20, weight: .bold, design: .default))
//                    //.font(.primary(.bold, size: 20))
//                        .foregroundColor(.secondary)
//                        .padding(.leading)
//                    
//                    VStack(alignment: .leading) {
//                        
//                        SetUpStepsView(stepText: "Click on any Text Box, so that the default keyboard comes up.")
//                        CustomStepWithGlobeIconView()
//                        SetUpStepsView(stepText: "The secret text keyboard will appear and you will see 2 extra buttons on the keyboard(Encode and Decode)")
//                        SetUpStepsView(stepText: "Use Encode - If u want to send a msg.\nTo use Decode - Just copy the text to be decoded and hit the Decode button.")
//                        
//                    }.padding([.top, .bottom])
//                        .background(DiamondBackground())
//                    //.padding(.bottom)
//                    
//                    
//                    Spacer()
//                    
//                }
//                
//                Button(action: {
//                    isPresented.toggle()
//                }, label: {
//                    HStack {
//                        Text("Give it a try")
//                            .font(.primary(.semiBold, size: 16))
//                        Image(systemName: "arrow.right")
//                    }
//                    .fullScreenCover(isPresented: $isPresented, content: {
//                        DemoView()
//                    })
//                    .foregroundColor(.white)
//                    //.padding()
//                    .frame(width: 164, height: 52)
//                    .background(Color.primaryColor)
//                    .cornerRadius(30.5)
//                    .padding(.trailing)
//                })
//            }
////        }
//    }
//}
//
//struct DiamondBackground: View {
//    var body: some View {
//        VStack {
//            Rectangle()
//                .fill(Color.init(hex: 0xC433FF))
//                .opacity(0.5)
//                //.frame(width: 250, height: 250, alignment: .center)
//                //.rotationEffect(.degrees(45.0))
//        }
//        //.padding()
//    }
//    
//}
//
//
//struct SetUpStepsView: View {
//        
//    var stepText: String
//    
//    var body: some View {
//        
//        HStack {
//            
//            Image("secretagent3")
//                .resizable()
//                .frame(width: 25, height: 25, alignment: .center)
//                .padding(.trailing)
//
//            Text(stepText)
//                .font(.primary(.medium, size: 15))
//                .foregroundColor(.primary)
//                .fixedSize(horizontal: false, vertical: true)
//
//        }
//        .padding(.leading)
//    }
//    
//}
//
//struct CustomStepWithGlobeIconView: View {
//    
//    var body: some View {
//        
//        HStack {
//            
//            Image("secretagent3")
//                .resizable()
//                .frame(width: 25, height: 25, alignment: .center)
//                .padding(.trailing)
//            
//            Text("Now click on ")
//                .font(.primary(.medium, size: 15))
//                .foregroundColor(.primary)
//                + Text(Image(systemName: "globe")) + Text(" icon & select Secret Text Keyboard.")
//                .font(.primary(.medium, size: 15))
//                .foregroundColor(.primary)
//
//        }
//        .padding(.leading)
//    }
//    
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
