//
//  Constants.swift
//  SecretKBExt
//
//  Created by Asadullah Jamadar on 02/07/2023.
//

import Foundation
import UIKit

struct Constants {
    static let hSpace: CGFloat = 6
    static let vSpace: CGFloat = 12

    static let nonLetterFont: CGFloat = 18
    static let buttonsHeight: CGFloat = 45//44
    
    static let landscapeButtonsHeight: CGFloat = 36
    
    static let portraitWidth: CGFloat = UIScreen.main.bounds.width
    static let landscapeWidth: CGFloat = UIScreen.main.bounds.width-(UIScreen.main.bounds.width/4)
 }
